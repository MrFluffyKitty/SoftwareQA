import java.util.HashMap;
import java.util.Map;

public class TaskService {
	// sets ID
	int ID = 0000;
	
	// initializes hashmap
	private final Map<String, Task> taskList = new HashMap<>();
	
	// gets id from hashmap
	public Task getTask(String ID) {
	    return taskList.get(ID);
	}
	
	// adds task
	public Task addTask(String name, String description) {
		ID++;
		String taskId = Integer.toString(ID);
		Task task = new Task(taskId, name, description);
	    return taskList.put(taskId, task);
	}
	
	// updates task using id
	public void updateTask(String taskId, String name, String description) {
	    Task task = getTask(taskId);
	    task.setName(name);
	    task.setDescription(description);
	}
	
	// deletes task using id
	public Task delTask(String ID) {
		return taskList.remove(ID);
	}
}
