import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
	
	private final Map<String, Task> taskList = new HashMap<>();
	
	@Test
	void testHashmapAndAddTask() {
		TaskService taskService = new TaskService();
		taskService.addTask("Leeroy", "Jenkins");
		assertNotNull(taskList.get("0001"));
	}
	
	@Test
	void testAddTaskAndDelTask() {
		TaskService taskService = new TaskService();
		taskService.addTask("Leeroy", "Jenkins");
		taskService.delTask("0002");
		assertTrue(taskList.containsKey("0001") && taskList.get("0002") == null);
	}
	
	@Test
	void testUpdateTaskAndGetTask() {
		TaskService taskService = new TaskService();
		taskService.addTask("Leeroy", "Jenkins");
		taskService.updateTask("0001", "Dishes", "wash the all the dishes in the sink.");
		assertTrue(taskList.containsKey("0001"));
	}
}
