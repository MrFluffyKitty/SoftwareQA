
public class Task {
	//variables
	private String ID;
	private String name;
	private String description;
	
	// constructor
	public Task (String ID, String name, String description) {
		setID(ID);
		setName(name);
		setDescription(description);
	}
	
	//getters and setters with input validation
	public String getID() {
		return ID;
	}
	
	public void setID(String ID) {
        if (ID == null || ID.length() > 10) {
        	throw new IllegalArgumentException("invalid ID");
        }
        this.ID = ID;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("invalid name");
		}
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("invalid description");
		}
		this.description = description;
	}
}
