import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {

	@Test
	void testTask() {
		Task task = new Task("1111", "Dishes", "wash the all the dishes in the sink.");
		assertTrue(task.getID().equals("1111"));
		assertTrue(task.getName().equals("Dishes"));
		assertTrue(task.getDescription().equals("wash the all the dishes in the sink."));
	}
	
	@Test
	void testTaskAllNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, null, null);
		});
	}
	
	@Test
	void testTaskIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1111111111111", "Jenkins", "Jenkins");
		});
	}
	
	@Test
	void testTaskNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1111", "LeeroyJenkins1111111111111111111111111", "Jenkins");
		});
	}
	
	@Test
	void testDescriptionNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("1111", "LeeroyJenkins", "Jenkins11111111111111111111111111111111111111111111111111111111111");
		});
	}
}
