import java.util.*;

public class Appointment {
	// variables
	String ID;
	Date Date;
	String Description;
	
	// constructor
	Appointment(String ID, Date Date, String Description) {
		setID(ID);
		setDate(Date);
		setDescription(Description);
	}
	
	// getters and setters
	public String getID() {
		return ID;
	}
	
	public void setID(String ID) {
        if (ID == null || ID.length() > 10) {
        	throw new IllegalArgumentException("invalid ID");
        }
        this.ID = ID;
	}
	
	public Date getDate() {
		return Date;
	}
	
	public void setDate(Date Date) {
		if (Date.equals(null) || Date.before(new Date())) {
			throw new IllegalArgumentException("invalid Date");
        }
		this.Date = Date;
	}
	
	public String getDescription() {
		return Description;
	}
	
	public void setDescription(String Description) {
        if (Description == null || Description.length() > 50) {
        	throw new IllegalArgumentException("invalid Description");
        }
        this.Description = Description;
	}
}
