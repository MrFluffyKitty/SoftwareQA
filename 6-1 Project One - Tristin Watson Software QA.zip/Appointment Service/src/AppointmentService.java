import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
	// sets ID
	int ID = 0000;
		
	// initializes hashmap
	private final Map<String, Appointment> appList = new HashMap<>();
		
	// gets id from hashmap
	public Appointment getAppointment(String ID) {
		return appList.get(ID);
	}
		
	// adds appointment
	public Appointment addAppointment(Date date, String description) {
		ID++;
		String taskId = Integer.toString(ID);
		Appointment appointment = new Appointment(taskId, date, description);
		return appList.put(taskId, appointment);
	}
		
	// deletes appointment using id
	public Appointment delAppointment(String ID) {
		return appList.remove(ID);
	}
}
