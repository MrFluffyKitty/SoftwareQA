import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {

	@Test
	void testAppointment() {
		Date Date = new Date();
		Appointment appointment = new Appointment("1111", Date, "Somewhere over the rainbow.");
		assertTrue(appointment.getID().equals("1111"));
		assertTrue(appointment.getDate().equals(Date));
		assertTrue(appointment.getDescription().equals("Somewhere over the rainbow."));
	}
	
	@Test
	void testAppointmentAllNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, null, null);
		});
	}
	
	@Test
	void testAppointmentIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1111111111111", new Date(), "Jenkins");
		});
	}
	
	@Test
	void testDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("1111", new Date(), "Jenkins11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111");
		});
	}
	
}

