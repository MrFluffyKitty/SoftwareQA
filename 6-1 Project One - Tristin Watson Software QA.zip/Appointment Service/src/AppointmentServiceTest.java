import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

	private final Map<String, Appointment> appList = new HashMap<>();
	
	@Test
	void testHashmapAndAddAppointment() {
		Date date = new Date();
		AppointmentService appService = new AppointmentService();
		appService.addAppointment(date, "Jenkins");
		assertNotNull(appList.get("0001"));
	}
	
	@Test
	void testAddTaskAndDelAppointment() {
		Date date = new Date();
		AppointmentService appService = new AppointmentService();
		appService.addAppointment(date, "Jenkins");
		appService.delAppointment("0002");
		assertTrue(appList.containsKey("0001") && appList.get("0002") == null);
	}
}

